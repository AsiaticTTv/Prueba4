class Atraccion {
    constructor(id, nombre, tipo, edadMinima, precio) {
      this.id = id;
      this.nombre = nombre;
      this.tipo = tipo;
      this.edadMinima = edadMinima;
      this.precio = precio;
    }
  
    get id() {
      return this._id;
    }
  
    set id(value) {
      if (value > 0) {
        this._id = value;
      } else {
        throw new Error("El ID debe ser un número positivo");
      }
    }
  
    get nombre() {
      return this._nombre;
    }
  
    set nombre(value) {
      if (value && typeof value === 'string') {
        this._nombre = value;
      } else {
        throw new Error("El nombre debe ser una cadena no vacía");
      }
    }
  
    get tipo() {
      return this._tipo;
    }
  
    set tipo(value) {
      if (value && typeof value === 'string') {
        this._tipo = value;
      } else {
        throw new Error("El tipo debe ser una cadena no vacía");
      }
    }
  
    get edadMinima() {
      return this._edadMinima;
    }
  
    set edadMinima(value) {
      if (value >= 0) {
        this._edadMinima = value;
      } else {
        throw new Error("La edad mínima debe ser un número no negativo");
      }
    }
  
    get precio() {
      return this._precio;
    }
  
    set precio(value) {
      if (value >= 0) {
        this._precio = value;
      } else {
        throw new Error("El precio debe ser un número no negativo");
      }
    }
  }
  
  export default Atraccion;
  