class Visitante {
    constructor(id, nombre, edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    get id() {
        return this._id;
    }

    set id(value) {
        if (Number.isInteger(value) && value > 0) {
            this._id = value;
        } else {
            throw new Error("El ID debe ser un número entero positivo");
        }
    }

    get nombre() {
        return this._nombre;
    }

    set nombre(value) {
        if (value && typeof value === 'string' && value.trim().length > 0) {
            this._nombre = value;
        } else {
            throw new Error("El nombre debe ser una cadena no vacía");
        }
    }

    get edad() {
        return this._edad;
    }

    set edad(value) {
        if (Number.isInteger(value) && value >= 0) {
            this._edad = value;
        } else {
            throw new Error("La edad debe ser un número entero no negativo");
        }
    }
}

export default Visitante;
