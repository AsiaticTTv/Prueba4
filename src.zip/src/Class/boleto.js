import Atraccion from './atraccion'; // Asegúrate de importar correctamente la clase Atraccion

class Boleto {
  constructor(id, visitante, atraccion, fecha, costo) {
    this.id = id;
    this.visitante = visitante;
    this.atraccion = atraccion;
    this.fecha = fecha;
    this.costo = costo;
  }

  get id() {
    return this._id;
  }

  set id(value) {
    if (value > 0) {
      this._id = value;
    } else {
      throw new Error("El ID debe ser un número positivo");
    }
  }

  get visitante() {
    return this._visitante;
  }

  set visitante(value) {
    if (value && typeof value === 'string') {
      this._visitante = value;
    } else {
      throw new Error("El visitante debe ser una cadena no vacía");
    }
  }

  get atraccion() {
    return this._atraccion;
  }

  set atraccion(value) {
    if (value instanceof Atraccion) { // Aquí utilizas Atraccion
      this._atraccion = value;
    } else {
      throw new Error("La atracción debe ser una instancia de la clase Atraccion");
    }
  }

  get fecha() {
    return this._fecha;
  }

  set fecha(value) {
    if (value instanceof Date) {
      this._fecha = value;
    } else {
      throw new Error("La fecha debe ser una instancia de Date");
    }
  }

  get costo() {
    return this._costo;
  }

  set costo(value) {
    if (value >= 0) {
      this._costo = value;
    } else {
      throw new Error("El costo debe ser un número no negativo");
    }
  }
}

export default Boleto;

  