import React, { useState, useEffect } from 'react';
import MostrarAtracciones from './Components/componenteAtraccion';
import MostrarVisitantes from './Components/componenteVisitante';
import MostrarBoletos from './Components/ComponenteBoleto';
import Boleto from './Class/boleto'; 
import Atraccion from './Class/atraccion'; 
import Visitante from './Class/visitante'; 
import './App.css';

const App = () => {
  const [atracciones, setAtracciones] = useState([]);
  const [visitantes, setVisitantes] = useState([]);
  const [boletos, setBoletos] = useState([]);

  const [visitanteSeleccionado, setVisitanteSeleccionado] = useState("");
  const [atraccionSeleccionada, setAtraccionSeleccionada] = useState("");
  const [fecha, setFecha] = useState("");
  const [costo, setCosto] = useState("");

  useEffect(() => {
    fetchAtracciones();
    fetchVisitantes();
  }, []);

  const fetchAtracciones = async () => {
    const response = await fetch('/api/atracciones');
    const data = await response.json();
    setAtracciones(data);
  };

  const fetchVisitantes = async () => {
    const response = await fetch('/api/visitantes');
    const data = await response.json();
    setVisitantes(data);
  };

  const agregarBoleto = () => {
    const visitanteId = parseInt(visitanteSeleccionado);
    const atraccionId = parseInt(atraccionSeleccionada);
    const visitante = visitantes.find(v => v.id === visitanteId);
    const atraccion = atracciones.find(a => a.id === atraccionId);

    if (visitante && atraccion) {
      if (visitante.edad < atraccion.edadMinima) {
        alert(`La edad mínima para la atracción ${atraccion.nombre} es ${atraccion.edadMinima} años.`);
        return;
      }

      let costoBoleto = atraccion.precio;
      if (visitante.edad < 12) {
        costoBoleto *= 0.5; // Descuento del 50% para menores de 12 años
      }

      const nuevoBoleto = new Boleto(boletos.length + 1, visitante, atraccion, fecha, costoBoleto);
      setBoletos([...boletos, nuevoBoleto]);

      // Reset form
      setVisitanteSeleccionado("");
      setAtraccionSeleccionada("");
      setFecha("");
      setCosto("");
    } else {
      alert('Debe seleccionar un visitante y una atracción válidos.');
    }
  };

  const actualizarBoleto = (index, boletoActualizado) => {
    const nuevosBoletos = boletos.map((boleto, i) => i === index ? boletoActualizado : boleto);
    setBoletos(nuevosBoletos);
  };

  const borrarBoleto = (index) => {
    const nuevosBoletos = boletos.filter((_, i) => i !== index);
    setBoletos(nuevosBoletos);
  };

  const agregarAtraccion = (atraccion) => {
    setAtracciones([...atracciones, atraccion]);
  };

  const actualizarAtraccion = (index, atraccionActualizada) => {
    const nuevasAtracciones = atracciones.map((atraccion, i) => i === index ? atraccionActualizada : atraccion);
    setAtracciones(nuevasAtracciones);
  };

  const borrarAtraccion = (index) => {
    const nuevasAtracciones = atracciones.filter((_, i) => i !== index);
    setAtracciones(nuevasAtracciones);
  };

  const agregarVisitante = (visitante) => {
    setVisitantes([...visitantes, visitante]);
  };

  const actualizarVisitante = (index, visitanteActualizado) => {
    const nuevosVisitantes = visitantes.map((visitante, i) => i === index ? visitanteActualizado : visitante);
    setVisitantes(nuevosVisitantes);
  };

  const borrarVisitante = (index) => {
    const nuevosVisitantes = visitantes.filter((_, i) => i !== index);
    setVisitantes(nuevosVisitantes);
  };

  return (
    <div className="container mt-5">
      <h1>Gestión de Parque de Diversiones</h1>
      <form id="boletoForm">
        <div className="form-group">
          <label htmlFor="i-visitanteSelect">Visitante</label>
          <select 
            id="i-visitanteSelect" 
            className="form-control"
            value={visitanteSeleccionado}
            onChange={e => setVisitanteSeleccionado(e.target.value)}
          >
            <option value="">Seleccione un visitante</option>
            {visitantes.map((visitante, index) => (
              <option key={index} value={visitante.id}>{visitante.nombre}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="i-atraccionSelect">Atracción</label>
          <select 
            id="i-atraccionSelect" 
            className="form-control"
            value={atraccionSeleccionada}
            onChange={e => setAtraccionSeleccionada(e.target.value)}
          >
            <option value="">Seleccione una atracción</option>
            {atracciones.map((atraccion, index) => (
              <option key={index} value={atraccion.id}>{atraccion.nombre}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="i-fecha">Fecha</label>
          <input 
            type="date" 
            id="i-fecha" 
            className="form-control"
            value={fecha}
            onChange={e => setFecha(e.target.value)}
          />
        </div>
        <button type="button" className="btn btn-primary" onClick={agregarBoleto}>Agregar Boleto</button>
      </form>
      <h2>Boletos</h2>
      <MostrarBoletos boletos={boletos} actualizarBoleto={actualizarBoleto} borrarBoleto={borrarBoleto} />
      <h2>Atracciones</h2>
      <MostrarAtracciones atracciones={atracciones} agregarAtraccion={agregarAtraccion} actualizarAtraccion={actualizarAtraccion} borrarAtraccion={borrarAtraccion} />
      <h2>Visitantes</h2>
      <MostrarVisitantes visitantes={visitantes} agregarVisitante={agregarVisitante} actualizarVisitante={actualizarVisitante} borrarVisitante={borrarVisitante} />
    </div>
  );
};

export default App;