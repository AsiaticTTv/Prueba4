import React from 'react';

const MostrarBoletos = ({ boletos, actualizarBoleto, borrarBoleto }) => {
  return (
    <div>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Visitante</th>
            <th>Atracción</th>
            <th>Fecha</th>
            <th>Costo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody id="boletoTableBody">
          {boletos.map((boleto, index) => (
            <tr key={index}>
              <td>{boleto.id}</td>
              <td>{boleto.visitante.nombre}</td>
              <td>{boleto.atraccion.nombre}</td>
              <td>{boleto.fecha}</td>
              <td>{boleto.costo.toFixed(2)}</td>
              <td>
                <button className="btn btn-warning" onClick={() => actualizarBoleto(index, boleto)}>Actualizar</button>
                <button className="btn btn-danger" onClick={() => borrarBoleto(index)}>Borrar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MostrarBoletos;

