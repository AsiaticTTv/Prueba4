import React, { useState } from 'react';

const MostrarAtracciones = ({ atracciones, agregarAtraccion, actualizarAtraccion, borrarAtraccion }) => {
  const [nombre, setNombre] = useState("");
  const [tipo, setTipo] = useState("");
  const [edadMinima, setEdadMinima] = useState("");
  const [precio, setPrecio] = useState("");

  const handleAgregar = () => {
    const nuevaAtraccion = new Atraccion(atracciones.length + 1, nombre, tipo, parseInt(edadMinima), parseFloat(precio));
    agregarAtraccion(nuevaAtraccion);
    setNombre("");
    setTipo("");
    setEdadMinima("");
    setPrecio("");
  };

  return (
    <div>
      <form>
        <div className="form-group">
          <label>Nombre</label>
          <input type="text" className="form-control" value={nombre} onChange={e => setNombre(e.target.value)} />
        </div>
        <div className="form-group">
          <label>Tipo</label>
          <input type="text" className="form-control" value={tipo} onChange={e => setTipo(e.target.value)} />
        </div>
        <div className="form-group">
          <label>Edad Mínima</label>
          <input type="number" className="form-control" value={edadMinima} onChange={e => setEdadMinima(e.target.value)} />
        </div>
        <div className="form-group">
          <label>Precio</label>
          <input type="number" className="form-control" value={precio} onChange={e => setPrecio(e.target.value)} />
        </div>
        <button type="button" className="btn btn-primary" onClick={handleAgregar}>Agregar Atracción</button>
      </form>
      <hr />
      {atracciones.map((atraccion, index) => (
        <div key={index}>
          <p>ID: {atraccion.id}</p>
          <p>Nombre: {atraccion.nombre}</p>
          <p>Tipo: {atraccion.tipo}</p>
          <p>Edad Mínima: {atraccion.edadMinima}</p>
          <p>Precio: {atraccion.precio}</p>
          <button className="btn btn-warning" onClick={() => actualizarAtraccion(index, atraccion)}>Actualizar</button>
          <button className="btn btn-danger" onClick={() => borrarAtraccion(index)}>Borrar</button>
          <hr />
        </div>
      ))}
    </div>
  );
};

export default MostrarAtracciones;


