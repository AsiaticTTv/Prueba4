import React, { useState } from 'react';

const MostrarVisitantes = ({ visitantes, agregarVisitante, actualizarVisitante, borrarVisitante }) => {
  const [nombre, setNombre] = useState("");
  const [edad, setEdad] = useState("");

  const handleAgregar = () => {
    const nuevoVisitante = new Visitante(visitantes.length + 1, nombre, parseInt(edad));
    agregarVisitante(nuevoVisitante);
    setNombre("");
    setEdad("");
  };

  return (
    <div>
      <form>
        <div className="form-group">
          <label>Nombre</label>
          <input type="text" className="form-control" value={nombre} onChange={e => setNombre(e.target.value)} />
        </div>
        <div className="form-group">
          <label>Edad</label>
          <input type="number" className="form-control" value={edad} onChange={e => setEdad(e.target.value)} />
        </div>
        <button type="button" className="btn btn-primary" onClick={handleAgregar}>Agregar Visitante</button>
      </form>
      <hr />
      {visitantes.map((visitante, index) => (
        <div key={index}>
          <p>ID: {visitante.id}</p>
          <p>Nombre: {visitante.nombre}</p>
          <p>Edad: {visitante.edad}</p>
          <button className="btn btn-warning" onClick={() => actualizarVisitante(index, visitante)}>Actualizar</button>
          <button className="btn btn-danger" onClick={() => borrarVisitante(index)}>Borrar</button>
          <hr />
        </div>
      ))}
    </div>
  );
};

export default MostrarVisitantes;
